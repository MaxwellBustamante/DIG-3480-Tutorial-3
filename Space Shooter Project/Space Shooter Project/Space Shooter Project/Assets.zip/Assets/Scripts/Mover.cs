﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour
{
    private float speed = -5.0f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.velocity = transform.forward * speed;
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            speed = -20.0f;
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            speed = -5.0f;
        }
    }
}
